#pragma once

void init_ctrl_Attitude();

void ctrl_Attitude();