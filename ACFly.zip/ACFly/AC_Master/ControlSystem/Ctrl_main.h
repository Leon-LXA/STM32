#pragma once

void init_ControlSystem();

void ctrl_main();